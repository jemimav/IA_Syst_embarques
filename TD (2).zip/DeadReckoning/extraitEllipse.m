function [da1, da2, theta_e] = extraitEllipse(SigmaP)

% Calculer les elements V : vecteurs propres et D : valeurs propres de
% SigmaP

da1 = D(1,1);
da2 = D(2,2);

% calculer l'orientation theta_e de l'ellipse d'incertitude en utilisant
% les composants du vecteur propre V(1)

if theta_e < 0
    theta_e = theta_e + pi
end

