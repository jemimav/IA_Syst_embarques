function [x_p, y_p, theta_p] = MajOdometrie(x, y, theta, delta_sg, delta_sd, L)

% calculer delta_s
% calculer delta_theta

x_p = 0; % completer ici
y_p = 0; % completer ici
theta_p = 0; % completer ici