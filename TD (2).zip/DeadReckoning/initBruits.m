%% Simulation des bruits (�cart-type) %%

% Bruits sur l'entr�e (pour simuler une commande mal appliqu�e)
sigmav = 10;
sigmaw = 1.5*pi/180;

% Bruits sur les capteurs (pour simuler le bruit de perception des encodeurs)
sigmaT = 0.1;
sigmaR = 0.1*pi/180;
