function SigmaPP = propageErreurs(SigmaP, ... ) % completer la liste d'arguments

% calculer delta_s
% calculer delta_theta

% calculer Sigma_Delta

nabla_f_p = [1  0  -delta_s * sin(theta + delta_theta / 2);
             0  1   delta_s * cos(theta + delta_theta / 2);
             0  0                   1                    ];

nabla_f_dg11 = 0.5 * cos(theta + delta_theta/2) - (delta_s / (2*L)) * sin(theta + delta_theta/2);
% calculer nabla_f_dg12 nabla_f_dg21 nabla_f_dg22 nabla_f_dg31 nabla_f_dg32

nabla_f_dg = [ nabla_f_dg11, nabla_f_dg12;
               nabla_f_dg21, nabla_f_dg22;
               nabla_f_dg31, nabla_f_dg32;]

% Calculer SigmaPP