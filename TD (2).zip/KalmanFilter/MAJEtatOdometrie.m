function [x, y, theta] = MAJEtatOdometrie(xi, yi, thetai, delta_sg, delta_sd, L)

delta_s = (delta_sg+delta_sd)/2;
delta_theta = (delta_sd-delta_sg)/L;

x = xi + delta_s*cos(thetai + delta_theta/2); %% Mise � jour sur x
y = yi + delta_s*sin(thetai + delta_theta/2); %% Mise � jour sur y
theta = thetai + delta_theta; %% Mise � jour sur l'orientation
             
