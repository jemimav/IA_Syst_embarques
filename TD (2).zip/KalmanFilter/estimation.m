function [x, y, theta, P] = estimation(xi, yi, thetai, Pi, v, H, SIGMAin)

% Calcul du gain de Kalman

% Estimation de l'etat

% Estimation de l'incertitude de l'etat

% Mise en forme
x = X(1);
y = X(2);
theta = X(3);

if(theta < 0)
    theta = theta + 2*pi;
end

