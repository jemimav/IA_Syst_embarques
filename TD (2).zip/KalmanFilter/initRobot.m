%%% Param�tres du robot %%%

r = 40;      % Rayon des roues [mm]
L = 315;     % Distance entre les roues du robot [mm]
demiL = L/2; 

vmoy = 60;          % Vitesse moyenne du robot en mm/s
braqAngleMax = 2.5; % Angle maximum de braquage en degr�s.

% Constantes repr�sentant les parametr�s non d�terministes  
% du moteur et de l'interaction de la rue avec le sol

kg = 1e-10;
kd = 1e-10;

