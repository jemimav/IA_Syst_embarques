function zPredit = predictionDeMesure(a_d, r_d, xi, yi, thetai)

for j = 1:length(a_d)
    zPredit(1, j) = a_d(j) - thetai;
    if (zPredit(1, j) < 0)
        zPredit(1, j) = zPredit(1, j) + 2*pi;
    end
    zPredit(2, j) = r_d(j) - xi*cos(a_d(j)) - yi*sin(a_d(j));
end


