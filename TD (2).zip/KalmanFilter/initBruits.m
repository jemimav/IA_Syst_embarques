%% Simulation des bruits (�cart-type) %%

% Bruits sur l'entr�e (pour simuler une commande mal appliqu�e)
sigmav = 2.5;
sigmaw = 1.5*pi/180;

% Bruits sur les capteurs (pour simuler le bruit de perception des odom�tres)
sigmaT = 2.5;
sigmaR = 2*pi/180;