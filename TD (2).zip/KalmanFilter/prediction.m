function [x, y, theta, P] = prediction(xi, yi, thetai, Pi, delta_sg, delta_sd, L, kg, kd)

% calculer delta_s et delta_theta

theta = thetai + delta_theta;

if theta < 0
   theta = theta + 2*pi;
end

%calculer x et y à partir de xi, yi, thetai et delta_theta

Q = [kd*abs(delta_sd)       0;
           0         kg*abs(delta_sg)];

Fx = [ 1  0 -delta_s*sin(thetai + delta_theta/2);
        % completer la matrice Fx jacobienne de l'etat

Fu = [ 0.5*cos(thetai + delta_theta/2) - (delta_s/2*L)*sin(thetai + delta_theta/2), ...
               0.5*cos(thetai + delta_theta/2) + (delta_s/(2*L))*sin(thetai + delta_theta/2);
        % completer la matrice Fu jacobienne de la mesure
   
P = Fx*Pi*Fx' + Fu*Q*Fu';
