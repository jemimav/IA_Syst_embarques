%% Localisation et Navigation de Robots - TD2 %%

clear all
close all
clc

addpath('outils/')

nbIter = 100; % Nombre d'instants de la simulation

figure(1)
clf
hold on

initEnviro; % Initialise le mod�le de l'environnement, c'est-�-dire l'ensemble 
            % des droites le mod�lisant dans le rep�re global
initRobot;  % Initialise les param�tres du robot
initBruits; % Param�tres des bruits pour simuler une commande mal 
            % appliqu�e et pour simuler l'incertitude des odom�tres
genereTrajs;% Generation de la trajectoire du robot s'il applique 
            % parfaitement la commande
            % Generation des droites qui d�limitent l'environnement
            % Generation de la trajectoire r�elle du robot (commande bruit�e)

% phig et phid sont les mesures successives des codeurs des roues (en radians)

% alpha_droites_obs et r_droites_obs sont les mesures issues de la
% perception exteroceptive : les param�tres des quatre droites per�ues,
% centr�s au rep�re du robot et ordonn�s selon l'angle (en premier, la
% droite per�ue face au robot, puis les autres en tournant dans le sens antihoraire)

% r est le rayon d'une roue
% L est la longueur de l'essieu

xOdom(1) = 0;
yOdom(1) = 0;
thetaOdom(1) = 0;

xEstime(1) = 0;
yEstime(1) = 0;
thetaEstime(1) = 0;

PEstime = 1e-4*eye(3);

g = 1; %% Parametre pour l'appariement 

for i=1:nbIter

    diff_phig = phig(i+1)-phig(i);
    diff_phid = -(phid(i+1)-phid(i));
    
    delta_sg = diff_phig*r;
    delta_sd = diff_phid*r;
    
    % Position calcul�e par odom�trie, pour faire la comparaison des r�sultats  
    % (fonction d�j� vue dans le TD1)
    [xOdom(i+1), yOdom(i+1), thetaOdom(i+1)] = ...
        MAJEtatOdometrie(xOdom(i), yOdom(i), thetaOdom(i), delta_sg, delta_sd, L);
    
    % 1. Phase de pr�diction  
    %
    % La fonction groupe les deux fonctions du TD1: "MAJEtatOdometrie" pour
    % la prediction de pose et "propageErreurs" pour le calcul de la matrice de covariance

    % -->  a completer ...
    
    % 2. Phase de correction (mise � jour de la pose du robot)
    
    [xEstime(i+1), yEstime(i+1), thetaEstime(i+1), PEstime] = correction(xPredit, yPredit, thetaPredit, PPredit, alpha_droites, r_droites, alpha_droites_obs(i,:), r_droites_obs(i,:), g);
    
%     [da1, da2, theta_e] = extraitEllipse(PEstime);
%     
%         if mod(i,5) == 0
%            drawellipse([xEstime(i+1), yEstime(i+1), theta_e], 3*sqrt(da1), 3*sqrt(da2), 'k');
%            plot(xEstime(i+1), yEstime(i+1),'k.','MarkerSize',14)
%         end
end
hl(4) = plot(xEstime,yEstime, 'k', 'LineWidth', 3);
hl(5) = plot(xOdom,yOdom, 'r', 'LineWidth', 3);

hold off
axis equal
axis([xmin xmax ymin ymax])
title('Trajectoires du robot unicycle')
xlabel('x [mm]')
ylabel('y [mm]')
 
h = legend(hl, ...
        ' Droites de l''environnement', ...
        ' Application parfaite de la commande', ...
        ' R�elle (commande bruit�e)', ... 
        ' Obtenue par EKF', ...
        ' Obtenue par odom�trie','Location','NorthWest');
set(h,'FontSize',10);
